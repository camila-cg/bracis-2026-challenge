#!/usr/bin/env python3
"""Valida estrutura, offsets, resolução canônica e diversidade do dataset."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import re
import sqlite3
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST_FIELDS = ["nivel", "documento_id", "arquivo"]
GOLD_FIELDS = ["nivel", "documento_id", "citacao_id", "inicio", "fim", "trecho", "tipo", "classificacao", "id_canonico"]
LEVELS = {"1", "2"}
TYPES = {"jurisprudencia", "lei"}
CLASSES = {"real", "inventada", "incompleta"}

MISSING_DATA_IN_SPAN = re.compile(
    r"\b(?:sem\s+(?:n[uú]mero|processo|indica[cç][aã]o|identifica[cç][aã]o|relator(?:a|ia)?)"
    r"|n[aã]o\s+identificad[ao]s?|relator(?:a|ia)?\s+n[aã]o\s+identificad[ao])\b",
    re.IGNORECASE,
)
JURIS_TRIBUNAL = re.compile(r"\b(?:STF|STJ|TST|TSE|STM)\b", re.IGNORECASE)
JURIS_YEAR = re.compile(r"\b(?:19|20)\d{2}\b")
JURIS_RELATOR = re.compile(r"\bRel\.\s*Min\.", re.IGNORECASE)
JURIS_CLASS = re.compile(
    r"\b(?:A[cç][aã]o|Agravo|Apela[cç][aã]o|Embargos?|Habeas\s+Corpus|Mandado\s+de\s+Seguran[cç]a|Reclama[cç][aã]o|Recurso)\b",
    re.IGNORECASE,
)
LAW_SOURCE = re.compile(
    r"\b(?:C[oó]digo\s+(?:Civil|de\s+Defesa\s+do\s+Consumidor)|"
    r"Consolida[cç][aã]o\s+das\s+Leis\s+do\s+Trabalho|Constitui[cç][aã]o\s+Federal|"
    r"Lei(?:\s+Complementar)?\s+n[ºo°]?\s*\d[\d.]*(?:/\d{4})?)\b",
    re.IGNORECASE,
)

# Evidência que deve aparecer no texto canônico após normalização alfanumérica.
# Súmulas cujo registro não traz o número usam evidência do próprio enunciado.
CANONICAL_EVIDENCE = {
    "10606184": "art14ofornecedordeservicos",
    "10647746": "art818oonusdaprova",
    "10652044": "art312aprisaopreventiva",
    "10718759": "art186aquelequeporacao",
    "10590194": "art290receberprepararproduzir",
    "1289712966": "violaa clausuladereservadeplenario".replace(" ", ""),
    "28893055": "art373oonusdaprova",
    "10641516": "art5otodossaoiguaisperantealei",
    "10641213": "art7osaodireitosdostrabalhadores",
    "10626510": "art93leicomplementardeiniciativa",
    "1431369957": "contratodeprestacaodeservicoslegalidade",
    "10637358": "art896caberecursoderevista",
    "11304039": "art1osaoinelegiveis",
    "10710324": "art477naextincaodocontratodetrabalho",
    "doc_0212": "1597443pr",
    "doc_0706": "16313720125090016",
    "doc_0511": "3334mg",
    "doc_0381": "1821253rs",
    "doc_0275": "68676ac",
    "doc_0175": "32714matogrossodosul",
    "doc_0315": "1205500sc",
    "doc_0574": "06009798520206200020",
    "doc_0420": "2222520126260095",
    "doc_0678": "1532007920085090322",
    "doc_0222": "1820970sc",
    "doc_0949": "70004246120227000000",
    "doc_0715": "10367820135030110",
    "doc_0499": "19840320146080000",
    "doc_0604": "1600009720105210006",
}

# Evidência mínima esperada no próprio trecho. A combinação id + evidência impede
# que um id existente, porém pertencente a outra fonte, passe pela validação.
CITATION_EVIDENCE = {
    "10606184": ("art14", "consumidor"),
    "10647746": ("art818", "trabalho"),
    "10652044": ("art312|artigo312", "cpp|codigodeprocessopenal"),
    "10718759": ("art186|artigo186", "civil"),
    "10590194": ("art290|artigo290", "cpm|codigopenalmilitar"),
    "1289712966": ("sumulavinculante10",),
    "28893055": ("art373", "cpc"),
    "10641516": ("art5|artigo5", "constitu"),
    "10641213": ("art7|artigo7", "cf88"),
    "10626510": ("art93", "constitu"),
    "1431369957": ("sumula331", "tst"),
    "10637358": ("art896", "clt"),
    "11304039": ("art1|artigo1", "leicomplementar641990"),
    "10710324": ("art477", "clt"),
    "doc_0212": ("1597443pr", "stj"),
    "doc_0706": ("16313720125090016", "tst"),
    "doc_0511": ("3334mg", "tribunalsuperioreleitoral"),
    "doc_0381": ("1821253rs", "stj"),
    "doc_0275": ("68676ac", "stj"),
    "doc_0175": ("32714ms", "stf"),
    "doc_0315": ("1205500sc", "stj"),
    "doc_0574": ("06009798520206200020", "tse"),
    "doc_0420": ("2222520126260095", "tse"),
    "doc_0678": ("1532007920085090322", "tst"),
    "doc_0222": ("1820970sc", "stj"),
    "doc_0949": ("70004246120227000000", "stm"),
    "doc_0715": ("10367820135030110", "tst"),
    "doc_0499": ("19840320146080000", "tse"),
    "doc_0604": ("1600009720105210006", "tst"),
}


def norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii").lower()
    value = value.replace("arnald0", "arnaldo")
    return re.sub(r"[^a-z0-9]+", "", value)


def read_csv(path: Path, expected: list[str]) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != expected:
            raise AssertionError(f"cabeçalho inválido em {path.name}: {reader.fieldnames}")
        rows = list(reader)
    return rows


def locate_db(explicit: str | None) -> Path:
    candidates = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    candidates += [ROOT / "desafio1_bracis.db", ROOT.parent / "desafio1_bracis.db", Path.cwd() / "desafio1_bracis.db"]
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise AssertionError("desafio1_bracis.db não encontrado; informe o caminho como argumento")


def shingles(text: str, width: int = 5) -> set[tuple[str, ...]]:
    words = re.findall(r"[a-z0-9]+", unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode().lower())
    return {tuple(words[i:i + width]) for i in range(max(0, len(words) - width + 1))}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("db", nargs="?", help="caminho para desafio1_bracis.db")
    args = parser.parse_args()
    db_path = locate_db(args.db)

    errors: list[str] = []
    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    try:
        manifest = read_csv(ROOT / "manifest.csv", MANIFEST_FIELDS)
        gold = read_csv(ROOT / "goldenset_offsets.csv", GOLD_FIELDS)
    except Exception as exc:
        print(f"ERRO: {exc}")
        return 1

    # 1–3, 10: inventário, unicidade, domínios e UTF-8.
    check(len(manifest) == 26, f"manifesto deve conter 26 documentos, contém {len(manifest)}")
    doc_ids = [row["documento_id"] for row in manifest]
    files = [row["arquivo"] for row in manifest]
    check(len(doc_ids) == len(set(doc_ids)), "documento_id duplicado")
    check(len(files) == len(set(files)), "arquivo duplicado no manifesto")
    check(set(row["nivel"] for row in manifest) == LEVELS, "os dois níveis devem estar presentes")
    check(Counter(row["nivel"] for row in manifest) == Counter({"1": 13, "2": 13}), "esperados 13 documentos por nível")

    texts: dict[str, str] = {}
    for row in manifest:
        check(row["nivel"] in LEVELS, f"nível inválido: {row}")
        path = (ROOT / row["arquivo"]).resolve()
        check(ROOT in path.parents, f"caminho escapa da pasta do dataset: {row['arquivo']}")
        check(path.is_file(), f"arquivo ausente: {row['arquivo']}")
        if path.is_file():
            try:
                texts[row["documento_id"]] = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                errors.append(f"arquivo não é UTF-8: {row['arquivo']}")
    actual_txt = {str(p.relative_to(ROOT)) for p in (ROOT / "txt").glob("*.txt")}
    check(actual_txt == set(files), "há .txt não manifestado ou arquivo manifestado fora de txt/")

    manifest_by_id = {row["documento_id"]: row for row in manifest}
    citation_keys = [(row["documento_id"], row["citacao_id"]) for row in gold]
    check(len(citation_keys) == len(set(citation_keys)), "citacao_id duplicado dentro de documento")

    # 4–6, 9: offsets, igualdade literal, sobreposição e ausência de id indevido.
    intervals: dict[str, list[tuple[int, int, str]]] = defaultdict(list)
    for line, row in enumerate(gold, start=2):
        prefix = f"goldenset linha {line}"
        check(row["documento_id"] in manifest_by_id, f"{prefix}: documento fora do manifesto")
        check(row["nivel"] in LEVELS, f"{prefix}: nível inválido")
        check(row["tipo"] in TYPES, f"{prefix}: tipo inválido")
        check(row["classificacao"] in CLASSES, f"{prefix}: classificação inválida")
        if row["documento_id"] in manifest_by_id:
            check(row["nivel"] == manifest_by_id[row["documento_id"]]["nivel"], f"{prefix}: nível diverge do manifesto")
        try:
            start, end = int(row["inicio"]), int(row["fim"])
        except ValueError:
            errors.append(f"{prefix}: offsets não inteiros")
            continue
        text = texts.get(row["documento_id"], "")
        check(0 <= start < end <= len(text), f"{prefix}: offsets fora dos limites")
        if 0 <= start <= end <= len(text):
            check(text[start:end] == row["trecho"], f"{prefix}: trecho não coincide com offsets")
        intervals[row["documento_id"]].append((start, end, row["citacao_id"]))
        if row["classificacao"] == "real":
            check(bool(row["id_canonico"]), f"{prefix}: real sem id_canonico")
        else:
            check(not row["id_canonico"], f"{prefix}: não real com id_canonico")
        if row["classificacao"] == "incompleta":
            trecho = row["trecho"]
            check(not MISSING_DATA_IN_SPAN.search(trecho),
                  f"{prefix}: comentário editorial sobre dado ausente dentro do span")
            if row["tipo"] == "jurisprudencia":
                check(bool(JURIS_TRIBUNAL.search(trecho)), f"{prefix}: jurisprudência incompleta sem tribunal")
                check(bool(JURIS_YEAR.search(trecho)), f"{prefix}: jurisprudência incompleta sem ano")
                check(bool(JURIS_RELATOR.search(trecho)), f"{prefix}: jurisprudência incompleta sem relator")
                check(bool(JURIS_CLASS.search(trecho)), f"{prefix}: jurisprudência incompleta sem classe processual")
            else:
                check(bool(LAW_SOURCE.search(trecho)), f"{prefix}: lei incompleta sem diploma identificável")
    for doc_id, spans in intervals.items():
        spans.sort()
        for left, right in zip(spans, spans[1:]):
            check(left[1] <= right[0], f"spans sobrepostos em {doc_id}: {left[2]} e {right[2]}")

    # 7–8: existência e compatibilidade canônica por tipo, metadados e evidência textual.
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    for line, row in enumerate(gold, start=2):
        if row["classificacao"] != "real" or not row["id_canonico"]:
            continue
        canonical = con.execute(
            "SELECT documento_id, tribunal, natureza, tipo, texto FROM documentos WHERE documento_id = ?",
            (row["id_canonico"],),
        ).fetchone()
        check(canonical is not None, f"goldenset linha {line}: id_canonico inexistente")
        if canonical is None:
            continue
        check(canonical["tipo"] == row["tipo"], f"goldenset linha {line}: tipo incompatível com registro canônico")
        expected_db = CANONICAL_EVIDENCE.get(row["id_canonico"])
        expected_cite = CITATION_EVIDENCE.get(row["id_canonico"])
        check(expected_db is not None and expected_cite is not None, f"goldenset linha {line}: regra de compatibilidade ausente")
        if expected_db:
            check(expected_db in norm(canonical["texto"]), f"goldenset linha {line}: evidência ausente no registro canônico")
        if expected_cite:
            cited = norm(row["trecho"])
            check(all(any(option in cited for option in token.split("|")) for token in expected_cite),
                  f"goldenset linha {line}: trecho incompatível com id_canonico")
        if row["tipo"] == "lei":
            check(canonical["natureza"] == "dispositivo", f"goldenset linha {line}: lei não aponta para dispositivo")
        else:
            check(canonical["natureza"] in {"acordao", "sumula"}, f"goldenset linha {line}: jurisprudência aponta para natureza inválida")
    con.close()

    # 11: round-trip CSV em memória preserva quantidade e todos os campos, inclusive novas linhas.
    memory = io.StringIO(newline="")
    writer = csv.DictWriter(memory, fieldnames=GOLD_FIELDS, lineterminator="\n")
    writer.writeheader()
    writer.writerows(gold)
    memory.seek(0)
    reopened = list(csv.DictReader(memory))
    check(reopened == gold, "round-trip do goldenset alterou linhas ou campos")

    # 12: diversidade documental, ausência de duplicatas e proximidade lexical excessiva.
    hashes = [hashlib.sha256(text.encode("utf-8")).hexdigest() for text in texts.values()]
    check(len(hashes) == len(set(hashes)), "documentos textualmente duplicados")
    shingle_map = {doc_id: shingles(text) for doc_id, text in texts.items()}
    ids = sorted(shingle_map)
    worst = (0.0, "", "")
    for i, left in enumerate(ids):
        for right in ids[i + 1:]:
            a, b = shingle_map[left], shingle_map[right]
            score = len(a & b) / max(1, len(a | b))
            if score > worst[0]:
                worst = (score, left, right)
    check(worst[0] < 0.34, f"documentos excessivamente próximos: {worst[1]} e {worst[2]} ({worst[0]:.3f})")
    first_lines = {next((line.strip() for line in text.splitlines() if line.strip()), "") for text in texts.values()}
    check(len(first_lines) >= 20, "baixa diversidade de aberturas documentais")
    check(len(gold) >= 70, "cobertura citacional insuficiente")
    type_counts = Counter(r["tipo"] for r in gold)
    class_counts = Counter(r["classificacao"] for r in gold)
    cross_counts = Counter((r["tipo"], r["classificacao"]) for r in gold)
    check(type_counts["jurisprudencia"] >= 40, "cobertura insuficiente de jurisprudência")
    check(type_counts["lei"] >= 20, "cobertura insuficiente de lei")
    check(type_counts["jurisprudencia"] > type_counts["lei"],
          "a distribuição deve manter predominância de jurisprudência, como no goldenset real")
    # Limiares assimétricos preservam a ordem observada no goldenset real.
    # Não há mais cota artificial para cada cruzamento tipo × classe.
    check(class_counts["real"] >= 30, "cobertura insuficiente da classe real")
    check(class_counts["inventada"] >= 20, "cobertura insuficiente da classe inventada")
    check(class_counts["incompleta"] >= 10, "cobertura insuficiente da classe incompleta")
    check(class_counts["real"] > class_counts["inventada"] > class_counts["incompleta"],
          "a ordem real > inventada > incompleta deve acompanhar o goldenset real")
    check(cross_counts[("lei", "incompleta")] <= cross_counts[("jurisprudencia", "incompleta")],
          "leis incompletas podem existir, mas não devem ser forçadas até equilibrar o cruzamento")
    check(any(doc_id not in intervals for doc_id in texts), "deve existir ao menos um documento sem citações")

    if errors:
        print(f"VALIDAÇÃO FALHOU: {len(errors)} erro(s)")
        for error in errors:
            print(f"- {error}")
        return 1

    print("VALIDAÇÃO OK")
    print(f"documentos={len(manifest)}; citações={len(gold)}; níveis={dict(sorted(Counter(r['nivel'] for r in manifest).items()))}")
    print(f"tipos={dict(sorted(Counter(r['tipo'] for r in gold).items()))}")
    print(f"classes={dict(sorted(Counter(r['classificacao'] for r in gold).items()))}")
    print(f"maior_jaccard_5gramas={worst[0]:.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
